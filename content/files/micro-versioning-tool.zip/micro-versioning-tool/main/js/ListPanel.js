(function() {
  var ListPanel,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  ListPanel = (function(_super) {

    __extends(ListPanel, _super);

    ListPanel.prototype.focusedIndex = 0;

    function ListPanel(editor, element, range, offset, listener, cueType) {
      this.listener = listener;
      this.hide = __bind(this.hide, this);

      this.focus = __bind(this.focus, this);

      this.focusToList = __bind(this.focusToList, this);

      this.show = __bind(this.show, this);

      this.select = __bind(this.select, this);

      ListPanel.__super__.constructor.call(this, editor, element, range, offset, cueType);
      this.componentElement.className += " ListPanel";
    }

    ListPanel.prototype.select = function(index) {
      this.listener.onSelect(index);
      return this.hide();
    };

    ListPanel.prototype.show = function() {
      this.focus(this.focusedIndex);
      ListPanel.__super__.show.call(this);
      this.focusToList();
      if (this.listener.onOpen != null) {
        return this.listener.onOpen(this);
      }
    };

    ListPanel.prototype.focusToList = function() {};

    ListPanel.prototype.focus = function(index) {
      this.focusedIndex = index;
      return this.listener.onFocus(index);
    };

    ListPanel.prototype.hide = function() {
      ListPanel.__super__.hide.call(this);
      if (this.listener.onClose != null) {
        return this.listener.onClose();
      }
    };

    return ListPanel;

  })(ScrollerBallon);

  window.ListPanel = ListPanel;

}).call(this);
