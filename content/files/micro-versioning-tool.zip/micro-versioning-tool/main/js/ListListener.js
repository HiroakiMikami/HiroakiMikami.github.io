(function() {
  var ListListener;

  ListListener = (function() {

    function ListListener(onFocus, onSelect, onClose, onKeyPress, onOpen) {
      this.onFocus = onFocus;
      this.onSelect = onSelect;
      this.onClose = onClose;
      this.onKeyPress = onKeyPress;
      this.onOpen = onOpen;
    }

    return ListListener;

  })();

  window.ListListener = ListListener;

}).call(this);
