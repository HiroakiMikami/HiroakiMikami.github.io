(function() {
  var Position;

  Position = (function() {

    function Position(top, left) {
      this.top = top;
      this.left = left;
    }

    return Position;

  })();

  window.Position = Position;

}).call(this);
