(function() {
  var Marker,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  Marker = (function(_super) {

    __extends(Marker, _super);

    Marker.prototype.marker = null;

    Marker.prototype.arrow = null;

    function Marker(editor, range, calculatePosition, cueType) {
      this.range = range;
      this.calculatePosition = calculatePosition;
      this.cueType = cueType;
      this.positionOption = __bind(this.positionOption, this);

      this.size = __bind(this.size, this);

      this.marker = document.createElement("a");
      this.arrow = document.createElement("a");
      this.marker.className = "Marker";
      this.arrow.className = "MarkerArrow";
      this.marker.appendChild(this.arrow);
      Marker.__super__.constructor.call(this, editor, this.marker);
    }

    Marker.prototype.size = function(renderer) {
      var x;
      x = this.marker.getBoundingClientRect();
      return new Rectangle(x.width, x.height);
    };

    Marker.prototype.positionOption = function(renderer) {
      var cursorIndex, doc, endIndex, p, startIndex;
      doc = this.editor.getSession().getDocument();
      cursorIndex = doc.positionToIndex(editor.getCursorPosition());
      startIndex = null;
      endIndex = null;
      switch (this.cueType) {
        case CueType.Folding:
          if (startIndex == null) {
            startIndex = doc.positionToIndex(new Point(this.range.start.row - 1, 0));
          }
          if (endIndex == null) {
            endIndex = doc.positionToIndex(new Point(this.range.end.row + 1, 0)) - 1;
          }
          break;
        case CueType.Side:
          if (startIndex == null) {
            startIndex = doc.positionToIndex(new Point(this.range.start.row, 0));
          }
          if (endIndex == null) {
            endIndex = doc.positionToIndex(new Point(this.range.end.row + 1, 0)) - 1;
          }
          break;
        default:
          if (startIndex == null) {
            startIndex = doc.positionToIndex(this.range.start);
          }
          if (endIndex == null) {
            endIndex = doc.positionToIndex(this.range.end);
          }
      }
      if ((startIndex <= cursorIndex && cursorIndex <= endIndex)) {
        p = this.calculatePosition(renderer);
        if ((p != null) && p.top < 0) {
          p.top = 0;
        }
        return p;
      } else {
        return null;
      }
    };

    return Marker;

  })(Component);

  window.Marker = Marker;

}).call(this);
