(function() {
  var ScrollbarBallon,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  ScrollbarBallon = (function(_super) {

    __extends(ScrollbarBallon, _super);

    ScrollbarBallon.prototype.marker = null;

    ScrollbarBallon.prototype.ballon = null;

    ScrollbarBallon.prototype.content = null;

    function ScrollbarBallon(editor, element, range, isFocused) {
      var elem;
      this.range = range;
      this.pointToTop = __bind(this.pointToTop, this);

      this.positionOption = __bind(this.positionOption, this);

      this.size = __bind(this.size, this);

      ScrollbarBallon.__super__.constructor.call(this, editor, "");
      if (isFocused) {
        this.componentElement.className += " FocusedScrollbarBallon";
      } else {
        this.componentElement.className += " ScrollbarBallon";
      }
      this.content = document.createElement("div");
      this.content.className = "Content";
      elem = new Element(element);
      if (elem.element != null) {
        this.content.appendChild(elem.element);
      } else {
        this.content.innerHTML = elem != null ? elem.html : void 0;
      }
      this.marker = document.createElement("div");
      this.marker.className = "BallonMarker";
      this.ballon = document.createElement("div");
      this.ballon.className = "Ballon";
      this.componentElement.appendChild(this.content);
      this.componentElement.appendChild(this.ballon);
      this.componentElement.appendChild(this.marker);
    }

    ScrollbarBallon.prototype.size = function(renderer) {
      var r1, r2, r3;
      r1 = this.ballon.getBoundingClientRect();
      r2 = this.marker.getBoundingClientRect();
      r3 = this.content.getBoundingClientRect();
      return new Rectangle(r1.width + r2.width + r3.width, r3.height);
    };

    ScrollbarBallon.prototype.positionOption = function(renderer) {
      var end, mid, s, start, top;
      start = this.pointToTop(this.editor, this.range.start);
      end = this.pointToTop(this.editor, this.range.end);
      mid = (start + end) / 2;
      s = this.getSize(renderer);
      top = mid - s.height / 2;
      if (top < 0) {
        top = 0;
      } else if (top > renderer.scroller.getBoundingClientRect().height) {
        top = renderer.scroller.getBoundingClientRect().height - s.height;
      }
      this.marker.style["top"] = "" + (start - top) + "px";
      this.marker.style["height"] = "" + (end - start) + "px";
      this.ballon.style["top"] = "" + (mid - top - 2) + "px";
      return {
        top: top,
        right: 0
      };
    };

    ScrollbarBallon.prototype.pointToTop = function(editor, point) {
      var heightPerLine, maxHeight, numOfLine;
      numOfLine = editor.getSession().getDocument().getAllLines().length;
      maxHeight = editor.renderer.scroller.getBoundingClientRect().height - Constants.ScrollbarBallon.ballonHeight * 2 - (Constants.Ballon.borderWidth * 2);
      heightPerLine = maxHeight / numOfLine;
      if (heightPerLine > Constants.ScrollbarBallon.maximumHeightPerLine) {
        heightPerLine = Constants.ScrollbarBallon.maximumHeightPerLine;
      }
      return point.row * heightPerLine + Constants.ScrollbarBallon.ballonHeight;
    };

    return ScrollbarBallon;

  })(Component);

  window.ScrollbarBallon = ScrollbarBallon;

}).call(this);
