(function() {
  var CueType;

  CueType = (function() {

    function CueType() {}

    CueType.InsertWord = "InsertWord";

    CueType.ReplaceWord = "ReplaceWord";

    CueType.Side = "Side";

    CueType.Folding = "Folding";

    return CueType;

  })();

  window.CueType = CueType;

}).call(this);
