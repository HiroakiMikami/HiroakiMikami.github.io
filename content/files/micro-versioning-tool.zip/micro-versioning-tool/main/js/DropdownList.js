(function() {
  var DropdownList,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  DropdownList = (function(_super) {

    __extends(DropdownList, _super);

    DropdownList.prototype.isSelectClick = false;

    DropdownList.prototype.elements = null;

    DropdownList.prototype.selectElement = null;

    DropdownList.prototype.cue = null;

    DropdownList.prototype.marker = null;

    function DropdownList(editor, elems, range, listener, defaultHeight) {
      var e, elem, getPosition, i, offset, option, tpe, _i, _ref,
        _this = this;
      this.defaultHeight = defaultHeight;
      this.unselectAllOptions = __bind(this.unselectAllOptions, this);

      this.focusToList = __bind(this.focusToList, this);

      this.remove = __bind(this.remove, this);

      this.size = __bind(this.size, this);

      this.show = __bind(this.show, this);

      this.elements = [];
      this.selectElement = document.createElement("select");
      this.selectElement.multiple = true;
      for (i = _i = 0, _ref = elems.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        elem = elems[i];
        option = document.createElement("option");
        option.value = i;
        e = new Element(elem);
        if (e.element != null) {
          option.appendChild(e.element);
        } else {
          option.innerHTML = e != null ? e.html : void 0;
        }
        this.selectElement.appendChild(option);
        option.onclick = function() {
          if (_this.isSelectClick) {
            return _this.select(_this.focusedIndex);
          }
        };
        this.elements.push(option);
      }
      tpe = range.start.column === range.end.column ? CueType.InsertWord : CueType.ReplaceWord;
      if (tpe === CueType.InsertWord) {
        offset = new Offset(-editor.renderer.characterWidth / 2, editor.renderer.lineHeight);
      } else {
        offset = new Offset(0, editor.renderer.lineHeight);
      }
      DropdownList.__super__.constructor.call(this, editor, this.selectElement, range, offset, listener, tpe);
      this.componentElement.className += " DropdownList";
      this.cue = new Cue(editor, range, tpe);
      getPosition = function(renderer) {
        var p;
        p = AceUtils.pointToPositionInScroller(renderer, _this.range.start);
        return new Position(p.top, 0);
      };
      this.marker = new Marker(editor, range, getPosition, tpe);
      editor.on("click", function(e) {
        return _this.hide();
      });
      this.selectElement.onchange = function() {
        if (_this.selectElement.selectedIndex === _this.focusedIndex) {
          _this.isSelectClick = true;
        } else {
          _this.isSelectClick = false;
        }
        _this.focus(_this.selectElement.selectedIndex);
        return _this.unselectAllOptions();
      };
      this.selectElement.onkeydown = function(e) {
        switch (e.keyCode) {
          case Constants.KeyCode.enter:
            return _this.select(_this.focusedIndex);
          case Constants.KeyCode.escape:
            return _this.hide();
          default:
            if (_this.listener.onKeyPress != null) {
              return _this.listener.onKeyPress(e);
            }
        }
      };
      this.cue.componentElement.onclick = function() {
        return _this.show();
      };
      this.marker.componentElement.onclick = function() {
        return _this.show();
      };
      this.cue.show();
      this.marker.show();
    }

    DropdownList.prototype.show = function() {
      DropdownList.__super__.show.call(this);
      return this.isSelectClick = false;
    };

    DropdownList.prototype.size = function(renderer) {
      var element, h, maxHeight, maxWidth, r, size, w, _i, _len, _ref;
      maxHeight = 0;
      maxWidth = 0;
      _ref = this.elements;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        element = _ref[_i];
        r = element.getBoundingClientRect();
        h = r.height;
        w = r.width;
        maxHeight = maxHeight > h ? maxHeight : h;
        maxWidth = maxWidth > w ? maxWidth : w;
      }
      size = Math.round(this.defaultHeight / maxHeight);
      if (size === 0) {
        size = 1;
      }
      if (size > this.elements.length) {
        size = this.elements.length;
      }
      this.selectElement.size = size;
      return new Rectangle(maxWidth + 20, maxHeight * Math.min(size, this.elements.length));
    };

    DropdownList.prototype.remove = function() {
      DropdownList.__super__.remove.call(this);
      this.cue.remove();
      return this.marker.remove();
    };

    DropdownList.prototype.focusToList = function() {
      return this.selectElement.focus();
    };

    DropdownList.prototype.focus = function(index) {
      var element, _i, _len, _ref;
      DropdownList.__super__.focus.call(this, index);
      _ref = this.elements;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        element = _ref[_i];
        element.className = "";
      }
      this.elements[index].className = "Focused";
      this.selectElement.focus();
      this.selectElement.selectedIndex = index;
      return this.unselectAllOptions();
    };

    DropdownList.prototype.unselectAllOptions = function() {
      var option, _i, _len, _ref, _results;
      _ref = this.selectElement.options;
      _results = [];
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        option = _ref[_i];
        _results.push(option.selected = false);
      }
      return _results;
    };

    return DropdownList;

  })(ListPanel);

  window.DropdownList = DropdownList;

}).call(this);
