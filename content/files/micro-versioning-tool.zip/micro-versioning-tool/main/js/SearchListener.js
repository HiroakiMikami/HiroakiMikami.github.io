(function() {
  var SearchListener;

  SearchListener = (function() {

    function SearchListener(onChangeFocusedResult, onChangeSearchText, onKeyPress) {
      this.onChangeFocusedResult = onChangeFocusedResult;
      this.onChangeSearchText = onChangeSearchText;
      this.onKeyPress = onKeyPress;
    }

    return SearchListener;

  })();

  window.SearchListener = SearchListener;

}).call(this);
