(function() {
  var SideList,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  SideList = (function(_super) {

    __extends(SideList, _super);

    SideList.prototype.cue = null;

    SideList.prototype.marker = null;

    function SideList(editor, elements, range, listener, width) {
      this.remove = __bind(this.remove, this);

      var getPosition,
        _this = this;
      SideList.__super__.constructor.call(this, editor, elements, range, new Offset(editor.renderer.characterWidth * 2, 0), listener, new Rectangle(width, null), CueType.Side);
      this.cue = new Cue(editor, range, CueType.Side);
      getPosition = function(renderer) {
        return _this.cue.positionOption(renderer);
      };
      this.marker = new Marker(editor, range, getPosition, CueType.Side);
      this.cue.componentElement.onclick = function() {
        return _this.show();
      };
      this.marker.componentElement.onclick = function() {
        return _this.show();
      };
      this.cue.show();
      this.marker.show();
    }

    SideList.prototype.remove = function() {
      SideList.__super__.remove.call(this);
      this.cue.remove();
      return this.marker.remove();
    };

    return SideList;

  })(LargeListPanel);

  window.SideList = SideList;

}).call(this);
