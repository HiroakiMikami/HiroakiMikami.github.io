(function() {
  var ReadableDiff;

  ReadableDiff = (function() {

    function ReadableDiff(deltas) {
      this.deltas = deltas;
    }

    ReadableDiff.prototype.simpleDelta = function(editor) {
      var delta, fragment, html, i, last, line, lines, nl, t, text, _i, _j, _k, _len, _ref, _ref1;
      text = [document.createElement("div")];
      text[0].className = "ace_line";
      text[0].style["height"] = "" + editor.renderer.lineHeight + "px";
      for (i = _i = 0, _ref = this.deltas.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        delta = this.deltas[i];
        if ((delta[0] === "Delete") && (i !== this.deltas.length - 1) && (this.deltas[i + 1][0] === "Insert")) {
          continue;
        }
        lines = delta[1].split("\n");
        for (i = _j = 0, _ref1 = lines.length; 0 <= _ref1 ? _j < _ref1 : _j > _ref1; i = 0 <= _ref1 ? ++_j : --_j) {
          line = lines[i];
          if (i !== 0) {
            nl = document.createElement("div");
            nl.className = "ace_line";
            nl.style["height"] = "" + editor.renderer.lineHeight + "px";
            text.push(nl);
          }
          last = text[text.length - 1];
          fragment = document.createElement("span");
          fragment.textContent = line;
          switch (delta[0]) {
            case "Delete":
              fragment.className = "delete";
              break;
            case "Insert":
              fragment.className = "insert";
              break;
            case "Hold":
              fragment.className = "hold";
          }
          last.appendChild(fragment);
        }
      }
      html = document.createElement("div");
      html.className = "Diff";
      for (_k = 0, _len = text.length; _k < _len; _k++) {
        t = text[_k];
        html.appendChild(t);
      }
      return html;
    };

    ReadableDiff.prototype.fullDelta = function(editor) {
      var delta, fragment, html, i, last, line, lines, nl, t, text, _i, _j, _k, _len, _len1, _ref, _ref1;
      text = [document.createElement("div")];
      text[0].className = "ace_line";
      text[0].style["height"] = "" + editor.renderer.lineHeight + "px";
      _ref = this.deltas;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        delta = _ref[_i];
        lines = delta[1].split("\n");
        for (i = _j = 0, _ref1 = lines.length; 0 <= _ref1 ? _j < _ref1 : _j > _ref1; i = 0 <= _ref1 ? ++_j : --_j) {
          line = lines[i];
          if (i !== 0) {
            nl = document.createElement("div");
            nl.className = "ace_line";
            nl.style["height"] = "" + editor.renderer.lineHeight + "px";
            text.push(nl);
          }
          last = text[text.length - 1];
          fragment = document.createElement("span");
          fragment.textContent = line;
          switch (delta[0]) {
            case "Delete":
              fragment.className = "delete";
              break;
            case "Insert":
              fragment.className = "insert";
              break;
            case "Hold":
              fragment.className = "hold";
          }
          last.appendChild(fragment);
        }
      }
      html = document.createElement("div");
      html.className = "Diff";
      for (_k = 0, _len1 = text.length; _k < _len1; _k++) {
        t = text[_k];
        html.appendChild(t);
      }
      return html;
    };

    return ReadableDiff;

  })();

  window.ReadableDiff = ReadableDiff;

}).call(this);
