(function() {
  var Rectangle;

  Rectangle = (function() {

    function Rectangle(width, height) {
      this.width = width;
      this.height = height;
    }

    return Rectangle;

  })();

  window.Rectangle = Rectangle;

}).call(this);
