(function() {
  var Cue,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  Cue = (function(_super) {

    __extends(Cue, _super);

    function Cue(editor, range, cueType) {
      var component;
      this.range = range;
      this.cueType = cueType;
      this.hideMore = __bind(this.hideMore, this);

      this.showMore = __bind(this.showMore, this);

      this.positionOption = __bind(this.positionOption, this);

      this.size = __bind(this.size, this);

      Cue.__super__.constructor.call(this, editor, "");
      switch (this.cueType) {
        case CueType.InsertWord:
          component = document.createElement("div");
          component.className = "InsertWordContent";
          this.componentElement.className += " InsertWordArrow";
          this.componentElement.appendChild(component);
          break;
        case CueType.ReplaceWord:
          this.componentElement.className += " UnderLine";
          break;
        case CueType.Side:
          this.componentElement.className += " SideLine";
          break;
        case CueType.Folding:
          component = document.createElement("div");
          component.className = "FoldingArrowContent";
          this.componentElement.className += " FoldingArrow";
          this.componentElement.appendChild(component);
          this.moreLine = document.createElement("div");
          this.moreLine.className = "UnderLine";
          this.componentElement.appendChild(this.moreLine);
      }
      this.show();
      this.hideMore();
    }

    Cue.prototype.size = function(renderer) {
      var doc, end, maxWidth, rect, start;
      start = AceUtils.pointToPositionInScroller(renderer, this.range.start);
      switch (this.cueType) {
        case CueType.ReplaceWord:
          end = AceUtils.pointToPositionInScroller(renderer, this.range.end);
          return new Rectangle(end.left - start.left, 0);
        case CueType.Side:
          doc = this.editor.getSession().getDocument();
          if ((this.range.end.row + 1) === editor.getSession().getDocument().getAllLines().length) {
            end = AceUtils.pointToPositionInScroller(renderer, new Point(this.range.end.row, 0));
            return new Rectangle(0, end.top - start.top + renderer.lineHeight);
          } else {
            end = AceUtils.pointToPositionInScroller(renderer, new Point(this.range.end.row + 1, 0));
            return new Rectangle(0, end.top - start.top);
          }
          break;
        case CueType.Folding:
          rect = this.componentElement.getBoundingClientRect();
          if (this.range.start.row !== 0) {
            maxWidth = AceUtils.pointToPositionInScroller(renderer, new Point(this.range.start.row - 1, editor.getSession().getLine(this.range.start.row - 1).length - 1)).left;
          }
          if (this.range.end.row !== (editor.getSession().getDocument().getAllLines().length - 1)) {
            maxWidth = Math.max(maxWidth, AceUtils.pointToPositionInScroller(renderer, new Point(this.range.start.row, editor.getSession().getLine(this.range.start.row).length - 1)).left);
          }
          return new Rectangle(maxWidth + renderer.characterWidth * 5, rect.height);
        default:
          rect = this.componentElement.getBoundingClientRect();
          return new Rectangle(rect.width, rect.height);
      }
    };

    Cue.prototype.positionOption = function(renderer) {
      var i, l, maxWidth, start, _i, _ref, _ref1;
      switch (this.cueType) {
        case CueType.Folding:
          if (AceUtils.isRangeInScreen(renderer, new Range(new Point(this.range.start.row, 0), new Point(this.range.start.row + 1, 0)))) {
            start = AceUtils.pointToPositionInScroller(renderer, new Point(this.range.start.row, 0));
            return new Position(start.top, 0);
          } else {
            return null;
          }
          break;
        default:
          if (AceUtils.isRangeInScreen(renderer, this.range)) {
            start = AceUtils.pointToPositionInScroller(renderer, this.range.start);
            switch (this.cueType) {
              case CueType.Side:
                maxWidth = 0;
                for (i = _i = _ref = this.range.start.row, _ref1 = this.range.end.row; _ref <= _ref1 ? _i <= _ref1 : _i >= _ref1; i = _ref <= _ref1 ? ++_i : --_i) {
                  l = AceUtils.pointToPositionInScroller(renderer, new Point(i, editor.getSession().getLine(i).length - 1));
                  maxWidth = maxWidth > l.left ? maxWidth : l.left;
                }
                return new Position(start.top, maxWidth + renderer.characterWidth * 2);
              default:
                return new Position(start.top + editor.renderer.lineHeight, start.left);
            }
          } else {
            return null;
          }
      }
    };

    Cue.prototype.showMore = function() {
      if (this.moreLine != null) {
        return this.moreLine.style["display"] = "";
      }
    };

    Cue.prototype.hideMore = function() {
      if (this.moreLine != null) {
        return this.moreLine.style["display"] = "none";
      }
    };

    return Cue;

  })(Component);

  window.Cue = Cue;

}).call(this);
