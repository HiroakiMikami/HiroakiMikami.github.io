(function() {
  var Constants;

  Constants = (function() {

    function Constants() {}

    Constants.KeyCode = {
      enter: 13,
      escape: 27,
      left: 37,
      right: 39,
      up: 38,
      down: 40,
      space: 32,
      s: 115,
      f: 102
    };

    Constants.Ballon = {
      backgroundColor: "#FFFFFF",
      borderColor: "#D3D3D3",
      borderWidth: 1
    };

    Constants.fontSize = 15;

    Constants.ScrollbarBallon = {
      maximumHeightPerLine: 10,
      ballonHeight: 10
    };

    Constants.CandidateSet = {
      additionalLines: 2
    };

    return Constants;

  })();

  window.Constants = Constants;

}).call(this);
