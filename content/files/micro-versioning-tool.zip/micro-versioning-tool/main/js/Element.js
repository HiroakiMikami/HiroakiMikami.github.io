(function() {
  var Element;

  Element = (function() {

    Element.prototype.html = null;

    Element.prototype.element = null;

    function Element(elem) {
      if (elem.html != null) {
        this.html || (this.html = elem.html);
      } else if (elem.element != null) {
        this.element || (this.element = elem.element);
      } else if (typeof elem === "string") {
        this.html || (this.html = elem);
      } else {
        this.element || (this.element = elem);
      }
    }

    return Element;

  })();

  window.Element = Element;

}).call(this);
