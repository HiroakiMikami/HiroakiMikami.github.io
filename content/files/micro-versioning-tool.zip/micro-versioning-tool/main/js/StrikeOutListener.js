(function() {
  var StrikeOutListener;

  StrikeOutListener = (function() {

    function StrikeOutListener(onClick) {
      this.onClick = onClick;
    }

    return StrikeOutListener;

  })();

  window.StrikeOutListener = StrikeOutListener;

}).call(this);
