(function() {
  var ScrollerBallon,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  ScrollerBallon = (function(_super) {

    __extends(ScrollerBallon, _super);

    function ScrollerBallon(editor, element, range, offset, cueType) {
      this.range = range;
      this.offset = offset;
      this.cueType = cueType;
      this.size = __bind(this.size, this);

      this.positionOption = __bind(this.positionOption, this);

      ScrollerBallon.__super__.constructor.call(this, editor, element);
      this.componentElement.className += " ScrollerBallon";
    }

    ScrollerBallon.prototype.positionOption = function(renderer) {
      var i, l, maxWidth, start, _i, _ref, _ref1;
      start = null;
      switch (this.cueType) {
        case CueType.Folding:
          if (AceUtils.isRangeInScreen(renderer, new Range(new Point(this.range.start.row, 0), new Point(this.range.start.row + 1, 0)))) {
            if (start == null) {
              start = AceUtils.pointToPositionInScroller(renderer, new Point(this.range.start.row, 0));
            }
            maxWidth = 0;
            if (this.range.start.row !== 0) {
              maxWidth = AceUtils.pointToPositionInScroller(renderer, new Point(this.range.start.row - 1, editor.getSession().getLine(this.range.start.row - 1).length - 1)).left;
            }
            if (this.range.end.row !== (editor.getSession().getDocument().getAllLines().length - 1)) {
              maxWidth = Math.max(maxWidth, AceUtils.pointToPositionInScroller(renderer, new Point(this.range.start.row, editor.getSession().getLine(this.range.start.row).length - 1)).left);
            }
            return new Position(start.top, maxWidth + renderer.characterWidth * 5);
          } else {
            return null;
          }
          break;
        case CueType.Side:
          if (AceUtils.isRangeInScreen(renderer, this.range)) {
            start = AceUtils.pointToPositionInScroller(renderer, this.range.start);
            maxWidth = 0;
            if (this.range.start.row === this.range.end.row) {
              maxWidth = AceUtils.pointToPositionInScroller(renderer, new Point(this.range.start.row, editor.getSession().getLine(this.range.start.row).length - 1)).left;
            } else {
              for (i = _i = _ref = this.range.start.row, _ref1 = this.range.end.row; _ref <= _ref1 ? _i <= _ref1 : _i >= _ref1; i = _ref <= _ref1 ? ++_i : --_i) {
                l = AceUtils.pointToPositionInScroller(renderer, new Point(i, editor.getSession().getLine(i).length - 1));
                maxWidth = maxWidth > l.left ? maxWidth : l.left;
              }
            }
            start.left = maxWidth;
            if (this.offset != null) {
              start.top += this.offset.y;
              start.left += this.offset.x;
            }
            return start;
          } else {
            return null;
          }
          break;
        default:
          if (AceUtils.isRangeInScreen(renderer, this.range)) {
            start = AceUtils.pointToPositionInScroller(renderer, this.range.start);
            if (this.offset != null) {
              start.top += this.offset.y;
              start.left += this.offset.x;
            }
            return start;
          } else {
            return null;
          }
      }
    };

    ScrollerBallon.prototype.size = function(renderer) {
      var r;
      r = this.componentElement.getBoundingClientRect();
      return new Rectangle(r.width, r.height);
    };

    return ScrollerBallon;

  })(Component);

  window.ScrollerBallon = ScrollerBallon;

}).call(this);
