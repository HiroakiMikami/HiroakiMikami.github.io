(function() {
  var LargeListPanel,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  LargeListPanel = (function(_super) {

    __extends(LargeListPanel, _super);

    LargeListPanel.prototype.scroller = null;

    LargeListPanel.prototype.leftButton = null;

    LargeListPanel.prototype.rightButton = null;

    LargeListPanel.prototype.information = null;

    LargeListPanel.prototype.elements = null;

    function LargeListPanel(editor, elems, range, offset, listener, rectangle, cueType) {
      var control, div, e, elem, _i, _len,
        _this = this;
      this.rectangle = rectangle;
      this.size = __bind(this.size, this);

      this.focusToList = __bind(this.focusToList, this);

      LargeListPanel.__super__.constructor.call(this, editor, "", range, offset, listener, cueType);
      this.elements = [];
      this.componentElement.className += " LargeListPanel";
      this.componentElement.tabIndex = "0";
      this.scroller = document.createElement("div");
      this.scroller.className = "Scroller";
      for (_i = 0, _len = elems.length; _i < _len; _i++) {
        elem = elems[_i];
        div = document.createElement("div");
        div.className = "Element";
        div.style["visibility"] = "hidden";
        e = new Element(elem);
        if (e.element != null) {
          div.appendChild(e.element);
        } else {
          div.innerHTML = e != null ? e.html : void 0;
        }
        div.onclick = function() {
          return _this.select(_this.focusedIndex);
        };
        this.scroller.appendChild(div);
        this.elements.push(div);
      }
      this.componentElement.appendChild(this.scroller);
      control = document.createElement("div");
      this.leftButton = document.createElement("a");
      this.rightButton = document.createElement("a");
      this.information = document.createElement("a");
      control.className = "ControlPanel";
      this.leftButton.className = "MoveToLeft";
      this.rightButton.className = "MoveToRight";
      this.information.className = "Information";
      control.appendChild(this.leftButton);
      control.appendChild(this.information);
      control.appendChild(this.rightButton);
      this.componentElement.appendChild(control);
      this.leftButton.onclick = function() {
        return _this.focus(_this.focusedIndex - 1);
      };
      this.rightButton.onclick = function() {
        return _this.focus(_this.focusedIndex + 1);
      };
      this.componentElement.onkeypress = function(e) {
        switch (e.keyCode) {
          case Constants.KeyCode.enter:
            return _this.select(_this.focusedIndex);
        }
      };
      this.componentElement.onkeydown = function(e) {
        switch (e.keyCode) {
          case Constants.KeyCode.escape:
            return _this.hide();
          case Constants.KeyCode.left:
            if (_this.focusedIndex !== 0) {
              return _this.focus(_this.focusedIndex - 1);
            }
            break;
          case Constants.KeyCode.right:
            if ((_this.focusedIndex + 1) < _this.elements.length) {
              return _this.focus(_this.focusedIndex + 1);
            }
            break;
          default:
            if (_this.listener.onKeyPress != null) {
              return _this.listener.onKeyPress(e);
            }
        }
      };
      this.editor.on("click", function(e) {
        return _this.hide();
      });
    }

    LargeListPanel.prototype.focusToList = function() {
      return this.componentElement.focus();
    };

    LargeListPanel.prototype.focus = function(index) {
      var element, _i, _len, _ref;
      _ref = this.elements;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        element = _ref[_i];
        element.style["visibility"] = "hidden";
        element.style["display"] = "block";
      }
      this.elements[index].style["visibility"] = "";
      this.elements[index].style["display"] = "";
      LargeListPanel.__super__.focus.call(this, index);
      this.render(this.editor.renderer);
      this.information.innerHTML = "" + (index + 1) + "/" + this.elements.length;
      if (index === 0) {
        this.leftButton.style["visibility"] = "hidden";
      } else {
        this.leftButton.style["visibility"] = "";
      }
      if ((index + 1) === this.elements.length) {
        this.rightButton.style["visibility"] = "hidden";
      } else {
        this.rightButton.style["visibility"] = "";
      }
      return this.focusToList();
    };

    LargeListPanel.prototype.size = function(renderer) {
      var elem, h, height, rect, w, width;
      w = 0;
      h = 0;
      width = (function() {
        var _i, _len, _ref, _results;
        _ref = this.elements;
        _results = [];
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          elem = _ref[_i];
          rect = elem.getBoundingClientRect();
          w = Math.max(w, rect.width);
          _results.push(h = Math.max(h, rect.height));
        }
        return _results;
      }).call(this);
      height = null;
      width = null;
      if (this.rectangle != null) {
        height || (height = this.rectangle.height);
        width || (width = this.rectangle.width);
      }
      if (height == null) {
        height = h;
      }
      if (width == null) {
        width = w;
      }
      return new Rectangle(Math.max(90, width), height + 30);
    };

    return LargeListPanel;

  })(ListPanel);

  window.LargeListPanel = LargeListPanel;

}).call(this);
