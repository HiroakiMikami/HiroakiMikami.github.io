(function() {
  var Offset;

  Offset = (function() {
    /*
      ---------->x
      |
      |
      |
      |
      y
    */

    function Offset(x, y) {
      this.x = x;
      this.y = y;
    }

    return Offset;

  })();

  window.Offset = Offset;

}).call(this);
