(function() {
  var Client,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Client = (function() {

    Client.prototype.path = null;

    Client.prototype.apiServer = "http://" + window.location.host + "/protocol";

    Client.prototype.preview = null;

    Client.prototype.searchForm = null;

    Client.prototype.candidateSet = null;

    Client.prototype.canBeUpdated = true;

    function Client(editor, preview) {
      var searchListener,
        _this = this;
      this.editor = editor;
      this.closeSearchFrom = __bind(this.closeSearchFrom, this);

      this.focusSearchForm = __bind(this.focusSearchForm, this);

      this.openPreviousFocusedDiff = __bind(this.openPreviousFocusedDiff, this);

      this.openNextFocusedDiff = __bind(this.openNextFocusedDiff, this);

      this.openPreviousCandidate = __bind(this.openPreviousCandidate, this);

      this.openNextCandidate = __bind(this.openNextCandidate, this);

      this.onKeyPress = __bind(this.onKeyPress, this);

      this.onChangeFocusedResult = __bind(this.onChangeFocusedResult, this);

      this.setSearchResult = __bind(this.setSearchResult, this);

      this.apply = __bind(this.apply, this);

      this.update = __bind(this.update, this);

      this.commit = __bind(this.commit, this);

      this.restart = __bind(this.restart, this);

      this.quit = __bind(this.quit, this);

      this.save = __bind(this.save, this);

      this.open = __bind(this.open, this);

      this.apiUrl = __bind(this.apiUrl, this);

      searchListener = new SearchListener(function(index) {
        return _this.onChangeFocusedResult(index);
      }, function(text) {
        return _this.update(text);
      }, function(e) {
        return _this.onKeyPress(e);
      });
      this.preview = new Preview(preview);
      this.searchForm = new SearchForm(this.editor.container, searchListener);
      this.editor.on("change", function(e) {
        if (_this.canBeUpdated) {
          _this.searchForm.clear();
          return _this.update(null);
        }
      });
      this.editor.commands.addCommand({
        name: "focusSearchForm",
        bindKey: {
          win: "alt-S",
          linux: "alt-S"
        },
        exec: function(editor) {
          return _this.focusSearchForm();
        }
      });
      this.editor.commands.addCommand({
        name: "openNextCandidate",
        bindKey: {
          win: "Ctrl-space",
          linux: "Ctrl-space"
        },
        exec: function(editor) {
          return _this.openNextCandidate();
        }
      });
      this.editor.commands.addCommand({
        name: "Preview",
        bindKey: {
          win: "alt-P",
          linux: "alt-P"
        },
        exec: function(editor) {
          return _this.commit();
        }
      });
    }

    Client.prototype.apiUrl = function(api) {
      return "" + this.apiServer + "?api=" + api;
    };

    Client.prototype.open = function(path) {
      var _this = this;
      this.canBeUpdated = false;
      this.path = path;
      return window.repository.applyFromJava("Open", JSON.stringify(path), function(err, d) {
        const data = JSON.parse(d)
        _this.editor.getSession().setValue(data.text);
        _this.canBeUpdated = true;
        return _this.commit();
      });
    };

    Client.prototype.save = function() {
      return window.repository.applyFromJava("Save", JSON.stringify(this.path));
    };

    Client.prototype.quit = function() {
      return window.repository.applyFromJava("Quit", "");
    };

    Client.prototype.restart = function() {
      window.repository.applyFromJava("Restart", "");
      return document.location.reload();
    };

    Client.prototype.commit = function() {
      var file,
        _this = this;
      file = {
        fileName: this.path,
        text: this.editor.getSession().getValue()
      };
      window.repository.applyFromJava("Commit", JSON.stringify(file), function(err, data) {
        const fs = require('fs')
        const content = fs.readFileSync(`${window.rootDir}/${file.fileName}`, 'utf8')
        _this.preview.element.contentDocument.documentElement.innerHTML = content
        return _this.update(null);
      });
    };

    Client.prototype.update = function(text) {
      var request,
        _this = this;
      request = {
        file: {
          "fileName": this.path,
          "text": this.editor.getSession().getValue()
        },
        textToSearch: text,
        regionToSearch: null
      };
      return window.repository.applyFromJava("UpdateCandidates", JSON.stringify(request), function(err, d) {
        const data = JSON.parse(d)
        if (_this.candidateSet != null) {
          _this.candidateSet.clear();
        }
        _this.candidateSet = new CandidateSet(_this.editor, data, _this.apply, _this.onKeyPress);
        if (text != null) {
          return _this.setSearchResult(data.focusableList);
        } else {
          return _this.setSearchResult(null);
        }
      });
    };

    Client.prototype.apply = function(id) {
      var request,
        _this = this;
      this.canBeUpdated = false;
      request = {
        file: {
          fileName: this.path,
          text: this.editor.getSession().getValue()
        },
        id: id
      };
      return window.repository.applyFromJava("ApplyCandidate", JSON.stringify(request), function(err, d) {
        const data = JSON.parse(d)
        /*
        var aceDiff, delta, document, _i, _len, _ref;
        aceDiff = new AceDiff(_this.editor, data.diff);
        _this.editor.getSession().getDocument().applyDeltas(aceDiff.deltas)
        */

        const fs = require('fs')
        const content = fs.readFileSync(`${window.rootDir}/${_this.path}`, 'utf8')
        _this.editor.getSession().setValue(content)

        _this.canBeUpdated = true;
        _this.update(null);

        _this.preview.element.contentDocument.documentElement.innerHTML = content
      });
    };

    Client.prototype.setSearchResult = function(list) {
      if (list != null) {
        this.searchForm.setNumberOfSearchResult(list.length);
        return this.searchForm.focus(0);
      } else {
        return this.searchForm.setNumberOfSearchResult(null);
      }
    };

    Client.prototype.onChangeFocusedResult = function(index) {
      if (this.candidateSet != null) {
        return this.candidateSet.focusToList(index);
      }
    };

    Client.prototype.onKeyPress = function(e) {
      if (e.ctrlKey) {
        switch (e.keyCode) {
          case Constants.KeyCode.up:
            return this.openPreviousFocusedDiff();
          case Constants.KeyCode.down:
            return this.openNextFocusedDiff();
          case Constants.KeyCode.space:
            return this.openNextCandidate();
          default:
            switch (e.charCode) {
              case Constants.KeyCode.space:
                return this.openNextCandidate();
            }
        }
      } else if (e.altKey) {
        switch (e.keyCode) {
          case Constants.KeyCode.s:
            return this.openSearchForm();
        }
      } else {
        switch (e.keyCode) {
          case Constants.KeyCode.escape:
            this.editor.focus();
            return this.closeSearchFrom();
        }
      }
    };

    Client.prototype.openNextCandidate = function() {
      if (this.candidateSet != null) {
        return this.candidateSet.focusToNextCandidate();
      }
    };

    Client.prototype.openPreviousCandidate = function() {};

    Client.prototype.openNextFocusedDiff = function() {
      if (this.candidateSet != null) {
        return this.candidateSet.focusToNextBallon();
      }
    };

    Client.prototype.openPreviousFocusedDiff = function() {
      if (this.candidateSet != null) {
        return this.candidateSet.focusToPreviousBallon();
      }
    };

    Client.prototype.focusSearchForm = function() {
      return this.searchForm.open();
    };

    Client.prototype.closeSearchFrom = function() {
      return this.searchForm.close();
    };

    return Client;

  })();

  window.Client = Client;

}).call(this);
