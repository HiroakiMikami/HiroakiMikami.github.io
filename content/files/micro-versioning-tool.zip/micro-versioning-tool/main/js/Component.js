(function() {
  var Component,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  Component = (function() {

    Component.prototype.isValid = true;

    Component.prototype.doesShow = false;

    Component.prototype.componentElement = null;

    Component.prototype._size = null;

    Component.prototype.size = function(renderer) {
      return new Rectangle(0, 0);
    };

    Component.prototype.getSize = function(renderer) {
      if (!(this._size != null)) {
        this._size = this.size(renderer);
      }
      return this._size;
    };

    Component.prototype.positionOption = function(renderer) {
      return null;
    };

    function Component(editor, element) {
      var elem,
        _this = this;
      this.editor = editor;
      this.render = __bind(this.render, this);

      this.remove = __bind(this.remove, this);

      this.hide = __bind(this.hide, this);

      this.show = __bind(this.show, this);

      this.positionOption = __bind(this.positionOption, this);

      this.getSize = __bind(this.getSize, this);

      this.size = __bind(this.size, this);

      this.componentElement = document.createElement("div");
      this.componentElement.className = "Component";
      elem = new Element(element);
      if (elem.element != null) {
        this.componentElement.appendChild(elem.element);
      } else {
        this.componentElement.innerHTML = elem.html;
      }
      this.editor.container.appendChild(this.componentElement);
      this.editor.renderer.on("afterRender", function(e, renderer) {
        return _this.render(renderer);
      });
      this.editor.renderer.scrollBarH.on("scroll", function(e) {
        return _this.render(_this.editor.renderer);
      });
      this.editor.renderer.scrollBarV.on("scroll", function(e) {
        return _this.render(_this.editor.renderer);
      });
      this.hide();
    }

    Component.prototype.show = function() {
      this.doesShow = true;
      return this.render(this.editor.renderer);
    };

    Component.prototype.hide = function() {
      this.doesShow = false;
      return this.render(this.editor.renderer);
    };

    Component.prototype.remove = function() {
      if (this.isValid) {
        this.editor.container.removeChild(this.componentElement);
      }
      return this.isValid = false;
    };

    Component.prototype.render = function(renderer) {
      var position, size;
      if (!this.isValid) {
        return null;
      }
      this.componentElement.style["display"] = "block";
      if (this.doesShow) {
        position = this.positionOption(renderer);
        if (position != null) {
          this.componentElement.style["top"] = "" + position.top + "px";
          if (position.left != null) {
            this.componentElement.style["left"] = "" + (position.left + editor.renderer.gutterWidth) + "px";
          } else if (position.right != null) {
            this.componentElement.style["right"] = "" + position.right + "px";
          }
          size = this.getSize(renderer);
          this.componentElement.style["width"] = "" + size.width + "px";
          this.componentElement.style["height"] = "" + size.height + "px";
        } else {
          this.componentElement.style["display"] = "none";
        }
      } else {
        this.componentElement.style["display"] = "none";
      }
      return position;
    };

    return Component;

  })();

  window.Component = Component;

}).call(this);
