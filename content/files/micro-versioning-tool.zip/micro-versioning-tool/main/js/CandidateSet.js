(function() {
  var CandidateSet,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  CandidateSet = (function() {

    CandidateSet.prototype.listSet = null;

    CandidateSet.prototype.ballonSet = null;

    CandidateSet.prototype.lineBallonSet = null;

    CandidateSet.prototype.lineFocusedBallonSet = null;

    CandidateSet.prototype.strikeOutSet = null;

    CandidateSet.prototype.cueSet = null;

    CandidateSet.prototype.idSetWithDescripters = null;

    CandidateSet.prototype.indexOfFocusedBallon = null;

    CandidateSet.prototype.openedId = null;

    CandidateSet.prototype.duringOnOpen = false;

    CandidateSet.prototype.duringOnSelect = false;

    function CandidateSet(editor, candidateSet, apply, onKeyPress) {
      var deltas, elem, elements, id, ids, list, listener, onCloseBuilder, onFocusBuilder, onOpenBuilder, onSelectBuilder, _i, _j, _len, _len1, _ref, _ref1,
        _this = this;
      this.editor = editor;
      this.candidateSet = candidateSet;
      this.apply = apply;
      this.candidateList = __bind(this.candidateList, this);

      this.focusToNextCandidate = __bind(this.focusToNextCandidate, this);

      this.focusToBallon = __bind(this.focusToBallon, this);

      this.focusToPreviousBallon = __bind(this.focusToPreviousBallon, this);

      this.focusToNextBallon = __bind(this.focusToNextBallon, this);

      this.focusToList = __bind(this.focusToList, this);

      this.clear = __bind(this.clear, this);

      this.onSelect = __bind(this.onSelect, this);

      this.onFocus = __bind(this.onFocus, this);

      this.deactivateAll = __bind(this.deactivateAll, this);

      this.makeDescripters = __bind(this.makeDescripters, this);

      this.listSet = [];
      this.ballonSet = {};
      this.lineBallonSet = {};
      this.lineFocusedBallonSet = {};
      this.strikeOutSet = {};
      this.idSetWithDescripters = [];
      this.cueSet = {};
      onFocusBuilder = function(ids) {
        return function(i) {
          return _this.onFocus(ids[i]);
        };
      };
      onSelectBuilder = function(ids) {
        return function(i) {
          return _this.onSelect(ids[i]);
        };
      };
      onOpenBuilder = function() {
        return function(list) {
          var l, _i, _len, _ref;
          _this.duringOnOpen = true;
          _ref = _this.listSet;
          for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            l = _ref[_i];
            if (l !== list) {
              l.hide();
            }
          }
          return _this.duringOnOpen = false;
        };
      };
      onCloseBuilder = function() {
        return function() {
          if (!_this.duringOnOpen) {
            _this.deactivateAll();
            if (!_this.duringOnSelect) {
              _this.editor.focus();
              return _this.duringOnSelect = false;
            }
          }
        };
      };
      _ref = candidateSet.lists;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        list = _ref[_i];
        ids = [];
        elements = [];
        _ref1 = list.elements;
        for (_j = 0, _len1 = _ref1.length; _j < _len1; _j++) {
          elem = _ref1[_j];
          id = elem[0];
          ids.push(id);
          deltas = elem[1];
          elements.push({
            element: new ReadableDiff(deltas).simpleDelta(editor)
          });
        }
        listener = new ListListener(onFocusBuilder(ids), onSelectBuilder(ids), onCloseBuilder(), onKeyPress, onOpenBuilder());
        switch (list.tpe) {
          case "Line":
            if ((list.range.start.row === list.range.end.row) && (list.range.start.column === list.range.end.column)) {
              this.listSet.push(new FoldingList(editor, elements, new Range(new Point(list.range.start.row, 0), new Point(list.range.end.row, 0)), listener));
            } else {
              this.listSet.push(new SideList(editor, elements, list.range, listener, null));
            }
            break;
          case "Word":
            this.listSet.push(new DropdownList(editor, elements, list.range, listener, Constants.fontSize * 4));
        }
      }
    }

    CandidateSet.prototype.makeDescripters = function(id) {
      var ballon, delta, deltas, deltasFocused, diffFocused, diffNotFocused, doc, ds, elem, endRow, focused, focusedBallon, g, i, id_, index, isDelete, linesFocused, linesNotFocused, list, notFocused, onClick, onMouseEnterBuilder, onMouseLeaveBuilder, panel, r, range, rangeFocused, startRow, text, x, y, _base, _base1, _base2, _base3, _base4, _i, _j, _k, _l, _len, _len1, _len2, _len3, _len4, _len5, _len6, _m, _n, _o, _p, _q, _r, _ref, _ref1, _ref10, _ref11, _ref12, _ref13, _ref14, _ref15, _ref2, _ref3, _ref4, _ref5, _ref6, _ref7, _ref8, _ref9, _s,
        _this = this;
      onMouseEnterBuilder = function(index) {
        return function() {
          return _this.focusToBallon(index);
        };
      };
      onMouseLeaveBuilder = function(ballon) {
        return function() {
          ballon.hide();
          return _this.indexOfFocusedBallon = null;
        };
      };
      _ref = this.idSetWithDescripters;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        i = _ref[_i];
        if (i === id) {
          return;
        }
      }
      doc = this.editor.getSession().getDocument();
      _ref1 = this.candidateSet.lists;
      for (_j = 0, _len1 = _ref1.length; _j < _len1; _j++) {
        list = _ref1[_j];
        _ref2 = list.elements;
        for (_k = 0, _len2 = _ref2.length; _k < _len2; _k++) {
          elem = _ref2[_k];
          id_ = elem[0];
          if (id !== id_) {
            continue;
          }
          deltas = elem[1];
          isDelete = true;
          for (_l = 0, _len3 = deltas.length; _l < _len3; _l++) {
            delta = deltas[_l];
            if (delta[0] === "Insert") {
              isDelete = false;
            }
          }
          if (!isDelete) {
            panel = new ReadableDiff(deltas).simpleDelta(this.editor);
            if ((_ref3 = (_base = this.ballonSet)[id]) == null) {
              _base[id] = [];
            }
            if (list.tpe === "Word") {
              if (list.range.start.column === list.range.end.column) {
                this.ballonSet[id].push(new ScrollerBallon(this.editor, panel, list.range, new Offset(-this.editor.renderer.characterWidth / 2, this.editor.renderer.lineHeight), CueType.InsertWord));
              } else {
                this.ballonSet[id].push(new ScrollerBallon(this.editor, panel, list.range, new Offset(0, this.editor.renderer.lineHeight), CueType.ReplaceWord));
              }
            } else {
              if ((list.range.start.row === list.range.end.row) && (list.range.start.column === list.range.end.column)) {
                this.ballonSet[id].push(new ScrollerBallon(this.editor, panel, new Range(new Point(list.range.start.row, 0), new Point(list.range.end.row, 0)), new Offset(0, 0), CueType.Folding));
                if ((_ref4 = (_base1 = this.cueSet)[id]) == null) {
                  _base1[id] = [];
                }
                this.cueSet[id].push(new Cue(this.editor, new Range(new Point(list.range.start.row, 0), new Point(list.range.end.row, 0)), CueType.Folding));
              } else {
                this.ballonSet[id].push(new ScrollerBallon(this.editor, panel, list.range, new Offset(editor.renderer.characterWidth * 2, 0), CueType.Side));
              }
            }
          }
          index = doc.positionToIndex(list.range.start);
          for (_m = 0, _len4 = deltas.length; _m < _len4; _m++) {
            ds = deltas[_m];
            if (ds[0] === "Delete") {
              if ((_ref5 = (_base2 = this.strikeOutSet)[id]) == null) {
                _base2[id] = [];
              }
              r = new Range(doc.indexToPosition(index), doc.indexToPosition(index + ds[1].length));
              onClick = function() {
                var _len5, _n, _ref6, _results;
                _ref6 = _this.listSet;
                _results = [];
                for (_n = 0, _len5 = _ref6.length; _n < _len5; _n++) {
                  list = _ref6[_n];
                  _results.push(list.hide());
                }
                return _results;
              };
              this.strikeOutSet[id].push(new StrikeOut(this.editor, r, new StrikeOutListener(onClick)));
            }
            if (ds[0] !== "Insert") {
              index += ds[1].length;
            }
          }
        }
      }
      doc = this.editor.getSession().getDocument();
      _ref6 = this.candidateSet.lineDiff;
      for (_n = 0, _len5 = _ref6.length; _n < _len5; _n++) {
        x = _ref6[_n];
        id_ = x[0];
        if (id !== id_) {
          continue;
        }
        _ref7 = x[1];
        for (_o = 0, _len6 = _ref7.length; _o < _len6; _o++) {
          y = _ref7[_o];
          range = y[0];
          deltas = y[1];
          notFocused = document.createElement("div");
          notFocused.className = "LineDiff";
          diffNotFocused = new ReadableDiff(deltas).fullDelta(this.editor);
          diffNotFocused.className += " LineDiffContent";
          linesNotFocused = document.createElement("div");
          linesNotFocused.className = "Gutter";
          for (i = _p = _ref8 = range.start.row, _ref9 = range.end.row; _ref8 <= _ref9 ? _p < _ref9 : _p > _ref9; i = _ref8 <= _ref9 ? ++_p : --_p) {
            g = document.createElement("div");
            g.className = "ace gutter_cell";
            g.innerHTML = i + 1;
            g.style["height"] = "" + editor.renderer.lineHeight + "px";
            linesNotFocused.appendChild(g);
          }
          notFocused.appendChild(linesNotFocused);
          notFocused.appendChild(diffNotFocused);
          if ((_ref10 = (_base3 = this.lineBallonSet)[id]) == null) {
            _base3[id] = [];
          }
          if (range.start.row === range.end.row) {
            ballon = new ScrollbarBallon(this.editor, notFocused, new Range(new Point(range.start.row, 0), new Point(range.end.row + 1, 0)), false);
          } else {
            ballon = new ScrollbarBallon(this.editor, notFocused, range, false);
          }
          this.lineBallonSet[id].push(ballon);
          startRow = Math.max(range.start.row - Constants.CandidateSet.additionalLines, 0);
          endRow = Math.min(range.end.row + Constants.CandidateSet.additionalLines, doc.getAllLines().length);
          rangeFocused = new Range(new Point(startRow, 0), new Point(endRow, 0));
          deltasFocused = deltas;
          text = "";
          for (i = _q = startRow, _ref11 = range.start.row; startRow <= _ref11 ? _q < _ref11 : _q > _ref11; i = startRow <= _ref11 ? ++_q : --_q) {
            text += "" + (doc.getLine(i)) + "\n";
          }
          deltasFocused.unshift(["Hold", text]);
          text = "";
          for (i = _r = _ref12 = range.end.row; _ref12 <= endRow ? _r < endRow : _r > endRow; i = _ref12 <= endRow ? ++_r : --_r) {
            text += "\n" + (doc.getLine(i));
          }
          deltasFocused.push(["Hold", text]);
          focused = document.createElement("div");
          focused.className = "LineDiff";
          diffFocused = new ReadableDiff(deltasFocused).fullDelta(this.editor);
          diffFocused.className += " LineDiffContent";
          linesFocused = document.createElement("div");
          linesFocused.className = "Gutter";
          for (i = _s = _ref13 = rangeFocused.start.row, _ref14 = rangeFocused.end.row; _ref13 <= _ref14 ? _s < _ref14 : _s > _ref14; i = _ref13 <= _ref14 ? ++_s : --_s) {
            g = document.createElement("div");
            g.className = "ace gutter_cell";
            g.style["height"] = "" + editor.renderer.lineHeight + "px";
            g.innerHTML = i + 1;
            linesFocused.appendChild(g);
          }
          focused.appendChild(linesFocused);
          focused.appendChild(diffFocused);
          if ((_ref15 = (_base4 = this.lineFocusedBallonSet)[id]) == null) {
            _base4[id] = [];
          }
          focusedBallon = new ScrollbarBallon(this.editor, focused, rangeFocused, true);
          this.lineFocusedBallonSet[id].push(focusedBallon);
          ballon.componentElement.onmouseenter = onMouseEnterBuilder(this.lineFocusedBallonSet[id].length - 1);
          focusedBallon.componentElement.onmouseleave = onMouseLeaveBuilder(focusedBallon);
        }
      }
      return this.idSetWithDescripters.push(id);
    };

    CandidateSet.prototype.deactivateAll = function() {
      var ballon, cue, indexOfFocusedBallon, key, openedId, strikeOut, value, _i, _j, _k, _l, _len, _len1, _len2, _len3, _ref, _ref1, _ref2, _ref3, _ref4, _results;
      openedId = null;
      indexOfFocusedBallon = null;
      _ref = this.ballonSet;
      for (key in _ref) {
        value = _ref[key];
        for (_i = 0, _len = value.length; _i < _len; _i++) {
          ballon = value[_i];
          ballon.hide();
        }
      }
      _ref1 = this.lineBallonSet;
      for (key in _ref1) {
        value = _ref1[key];
        for (_j = 0, _len1 = value.length; _j < _len1; _j++) {
          ballon = value[_j];
          ballon.hide();
        }
      }
      _ref2 = this.lineFocusedBallonSet;
      for (key in _ref2) {
        value = _ref2[key];
        for (_k = 0, _len2 = value.length; _k < _len2; _k++) {
          ballon = value[_k];
          ballon.hide();
        }
      }
      _ref3 = this.strikeOutSet;
      for (key in _ref3) {
        value = _ref3[key];
        for (_l = 0, _len3 = value.length; _l < _len3; _l++) {
          strikeOut = value[_l];
          strikeOut.hide();
        }
      }
      _ref4 = this.cueSet;
      _results = [];
      for (key in _ref4) {
        value = _ref4[key];
        _results.push((function() {
          var _len4, _m, _results1;
          _results1 = [];
          for (_m = 0, _len4 = value.length; _m < _len4; _m++) {
            cue = value[_m];
            cue.hide();
            _results1.push(cue.hideMore());
          }
          return _results1;
        })());
      }
      return _results;
    };

    CandidateSet.prototype.onFocus = function(id) {
      var b, bs, lb, lbs, m, ms, s, ss, _i, _j, _k, _l, _len, _len1, _len2, _len3;
      this.deactivateAll();
      this.makeDescripters(id);
      bs = this.ballonSet[id] || [];
      for (_i = 0, _len = bs.length; _i < _len; _i++) {
        b = bs[_i];
        b.show();
      }
      lbs = this.lineBallonSet[id] || [];
      for (_j = 0, _len1 = lbs.length; _j < _len1; _j++) {
        lb = lbs[_j];
        if (!AceUtils.isRangeInScreen(this.editor.renderer, lb.range)) {
          lb.show();
        }
      }
      ss = this.strikeOutSet[id] || [];
      for (_k = 0, _len2 = ss.length; _k < _len2; _k++) {
        s = ss[_k];
        s.show();
      }
      ms = this.cueSet[id] || [];
      for (_l = 0, _len3 = ms.length; _l < _len3; _l++) {
        m = ms[_l];
        m.show();
        m.showMore();
      }
      return this.openedId = id;
    };

    CandidateSet.prototype.onSelect = function(id) {
      this.deactivateAll();
      this.editor.focus();
      this.duringOnSelect = true;
      return this.apply(id);
    };

    CandidateSet.prototype.clear = function() {
      var ballon, cue, key, list, strikeOut, value, _i, _j, _k, _l, _len, _len1, _len2, _len3, _len4, _m, _ref, _ref1, _ref2, _ref3, _ref4, _ref5, _results;
      _ref = this.listSet;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        list = _ref[_i];
        list.remove();
      }
      _ref1 = this.ballonSet;
      for (key in _ref1) {
        value = _ref1[key];
        for (_j = 0, _len1 = value.length; _j < _len1; _j++) {
          ballon = value[_j];
          ballon.remove();
        }
      }
      _ref2 = this.lineBallonSet;
      for (key in _ref2) {
        value = _ref2[key];
        for (_k = 0, _len2 = value.length; _k < _len2; _k++) {
          ballon = value[_k];
          ballon.remove();
        }
      }
      _ref3 = this.lineFocusedBallonSet;
      for (key in _ref3) {
        value = _ref3[key];
        for (_l = 0, _len3 = value.length; _l < _len3; _l++) {
          ballon = value[_l];
          ballon.remove();
        }
      }
      _ref4 = this.strikeOutSet;
      for (key in _ref4) {
        value = _ref4[key];
        for (_m = 0, _len4 = value.length; _m < _len4; _m++) {
          strikeOut = value[_m];
          strikeOut.remove();
        }
      }
      _ref5 = this.cueSet;
      _results = [];
      for (key in _ref5) {
        value = _ref5[key];
        _results.push((function() {
          var _len5, _n, _results1;
          _results1 = [];
          for (_n = 0, _len5 = value.length; _n < _len5; _n++) {
            cue = value[_n];
            _results1.push(cue.remove());
          }
          return _results1;
        })());
      }
      return _results;
    };

    CandidateSet.prototype.focusToList = function(index) {
      var elems, i, id, indexOfList, targetIndex, x, _i, _ref;
      if (this.candidateSet.focusableList != null) {
        this.deactivateAll();
        if (index >= this.candidateSet.focusableList.length) {
          return;
        }
        x = this.candidateSet.focusableList[index];
        indexOfList = x[0];
        id = x[1];
        targetIndex = null;
        elems = this.candidateSet.lists[indexOfList].elements || [];
        for (i = _i = 0, _ref = elems.length; 0 <= _ref ? _i <= _ref : _i >= _ref; i = 0 <= _ref ? ++_i : --_i) {
          if (elems[i][0] === id) {
            targetIndex = i;
            break;
          }
        }
        this.listSet[indexOfList].show();
        if (targetIndex != null) {
          return this.listSet[indexOfList].focus(targetIndex);
        }
      }
    };

    CandidateSet.prototype.focusToNextBallon = function() {
      var focusedBallons;
      if (this.openedId != null) {
        focusedBallons = this.lineFocusedBallonSet[this.openedId] || [];
        if (focusedBallons.length <= 0) {
          return;
        }
        if ((!(this.indexOfFocusedBallon != null)) || this.indexOfFocusedBallon < 0) {
          return this.focusToBallon(0);
        } else if (this.indexOfFocusedBallon + 1 === focusedBallons.length) {
          return this.focusToBallon(0);
        } else {
          return this.focusToBallon(this.indexOfFocusedBallon + 1);
        }
      }
    };

    CandidateSet.prototype.focusToPreviousBallon = function() {
      var focusedBallons;
      if (this.openedId != null) {
        focusedBallons = this.lineFocusedBallonSet[this.openedId] || [];
        if (focusedBallons.length <= 0) {
          return;
        }
        if (this.indexOfFocusedBallon <= 0) {
          return this.focusToBallon(0);
        } else {
          return this.focusToBallon(this.indexOfFocusedBallon - 1);
        }
      }
    };

    CandidateSet.prototype.focusToBallon = function(index) {
      var ballon, focusedBallons, _i, _len;
      focusedBallons = this.lineFocusedBallonSet[this.openedId] || [];
      if (focusedBallons.length <= 0) {
        return;
      }
      for (_i = 0, _len = focusedBallons.length; _i < _len; _i++) {
        ballon = focusedBallons[_i];
        ballon.hide();
      }
      focusedBallons[index].show();
      return this.indexOfFocusedBallon = index;
    };

    CandidateSet.prototype.focusToNextCandidate = function() {
      var i, index, ls, _i, _ref;
      ls = this.candidateList();
      if (ls.length === 0) {
        return;
      }
      index = null;
      for (i = _i = 0, _ref = ls.length; 0 <= _ref ? _i < _ref : _i > _ref; i = 0 <= _ref ? ++_i : --_i) {
        if (ls[i].doesShow) {
          if (index == null) {
            index = i;
          }
          break;
        }
      }
      if (index != null) {
        if (index === (ls.length - 1)) {
          return ls[0].show();
        } else {
          return ls[index + 1].show();
        }
      } else {
        return ls[0].show();
      }
    };

    CandidateSet.prototype.candidateList = function() {
      var cursorIndex, doc, endIndex, list, listSet, range, retval, startIndex, _i, _j, _len, _len1, _ref,
        _this = this;
      listSet = [];
      doc = this.editor.getSession().getDocument();
      cursorIndex = doc.positionToIndex(editor.getCursorPosition());
      _ref = this.listSet;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        list = _ref[_i];
        range = list.range;
        startIndex = doc.positionToIndex(range.start);
        endIndex = doc.positionToIndex(range.end);
        if (list.marker != null) {
          if (list.marker.componentElement.style["display"] !== "none") {
            listSet.push([endIndex - startIndex, range.end.row - range.start.row, list]);
          }
        }
      }
      listSet.sort(function(l1, l2) {
        if (l1[2].cueType !== l2[2].cueType) {
          switch (l1[2].cueType) {
            case CueType.InsertWord:
              switch (l2[2].cueType) {
                case CueType.Side:
                  return -1;
                case CueType.Folding:
                  return -1;
              }
              break;
            case CueType.ReplaceWord:
              switch (l2[2].cueType) {
                case CueType.Side:
                  return -1;
                case CueType.Folding:
                  return -1;
              }
              break;
            default:
              switch (l2[2].cueType) {
                case CueType.InsertWord:
                  return 1;
                case CueType.ReplaceWord:
                  return 1;
              }
          }
        } else if (l1[1] < l2[1]) {
          return -1;
        } else if (l1[1] > l2[1]) {
          return 1;
        } else if (l1[0] < l2[0]) {
          return -1;
        } else if (l1[0] > l2[0]) {
          return 1;
        }
        return 0;
      });
      retval = [];
      for (_j = 0, _len1 = listSet.length; _j < _len1; _j++) {
        list = listSet[_j];
        retval.push(list[2]);
      }
      return retval;
    };

    return CandidateSet;

  })();

  window.CandidateSet = CandidateSet;

}).call(this);
