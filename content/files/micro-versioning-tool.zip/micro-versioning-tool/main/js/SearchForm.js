(function() {
  var SearchForm;

  SearchForm = (function() {

    SearchForm.prototype.form = null;

    SearchForm.prototype.textarea = null;

    SearchForm.prototype.information = null;

    SearchForm.prototype.find = null;

    SearchForm.prototype.numberOfResult = null;

    SearchForm.prototype.focusedIndex = -1;

    SearchForm.prototype.searchedText = null;

    function SearchForm(parent, listener) {
      var _this = this;
      this.parent = parent;
      this.listener = listener;
      this.searchElement = document.createElement("div");
      this.form = document.createElement("div");
      this.form.className = "SearchForm";
      this.textarea = document.createElement("input");
      this.textarea.type = "text";
      this.textarea.className = "SearchText";
      this.information = document.createElement("div");
      this.information.className = "SearchInformation";
      this.find = document.createElement("input");
      this.find.type = "button";
      this.find.value = "Find";
      this.find.className = "SearchButton";
      this.form.appendChild(this.textarea);
      this.form.appendChild(this.information);
      this.form.appendChild(this.find);
      this.textarea.onkeydown = function(e) {
        return _this.listener.onKeyPress(e);
      };
      this.find.onclick = function() {
        var retval;
        if (((!(_this.searchedText != null)) || (_this.searchedText !== _this.textarea.value)) && (_this.textarea.value.length > 0)) {
          _this.searchedText = _this.textarea.value;
          retval = _this.listener.onChangeSearchText(_this.textarea.value);
          if (retval != null) {
            return _this.setNumberOfSearchResult(retval);
          }
        } else if ((_this.numberOfResult != null) && (_this.numberOfResult > 0)) {
          if ((_this.focusedIndex + 1) === _this.numberOfResult) {
            return _this.focus(0);
          } else {
            return _this.focus(_this.focusedIndex + 1);
          }
        }
      };
      this.parent.appendChild(this.form);
      this.close();
    }

    SearchForm.prototype.open = function() {
      this.form.style["display"] = "block";
      return this.textarea.focus();
    };

    SearchForm.prototype.close = function() {
      return this.form.style["display"] = "none";
    };

    SearchForm.prototype.clear = function() {
      this.numberOfResult = -1;
      this.searchedText = null;
      return this.numberOfResult = null;
    };

    SearchForm.prototype.focus = function(index) {
      this.focusedIndex = index;
      this.listener.onChangeFocusedResult(this.focusedIndex);
      return this.information.innerHTML = "" + (index + 1) + " of " + this.numberOfResult;
    };

    SearchForm.prototype.setNumberOfSearchResult = function(number) {
      if ((!(number != null)) || number < 0) {
        this.numberOfResult = -1;
      } else {
        this.numberOfResult = number;
      }
      if (number != null) {
        if (this.numberOfResult === 0) {
          return this.information.innerHTML = "not found";
        } else {
          return this.focus(0);
        }
      } else {
        return this.information.innerHTML = "";
      }
    };

    return SearchForm;

  })();

  window.SearchForm = SearchForm;

}).call(this);
