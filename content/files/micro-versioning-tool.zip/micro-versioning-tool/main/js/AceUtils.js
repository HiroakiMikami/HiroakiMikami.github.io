(function() {
  var AceUtils;

  AceUtils = (function() {

    function AceUtils() {}

    AceUtils.isInScreen = function(renderer, point) {
      var _ref;
      return (renderer.layerConfig.firstRow <= (_ref = point.row) && _ref <= renderer.layerConfig.lastRow);
    };

    AceUtils.isRangeInScreen = function(renderer, range) {
      return AceUtils.isInScreen(renderer, range.start) || AceUtils.isInScreen(renderer, range.end) || ((range.start.row <= renderer.layerConfig.firstRow) && (renderer.layerConfig.lastRow <= range.end.row));
    };

    AceUtils.pointToPositionInScroller = function(renderer, point) {
      var marginLeft, marginTop, positionInContent;
      positionInContent = renderer.$cursorLayer.getPixelPosition(point, true);
      marginTop = Number(renderer.content.style["margin-top"].replace("px", ""));
      marginLeft = Number(renderer.content.style["margin-left"].replace("px", ""));
      return new Position(positionInContent.top + marginTop, positionInContent.left + marginLeft);
    };

    return AceUtils;

  }).call(this);

  window.AceUtils = AceUtils;

}).call(this);
