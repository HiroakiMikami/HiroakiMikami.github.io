(function() {
  var AceDelta, AceDiff;

  AceDelta = (function() {

    function AceDelta(action, range, lines) {
      this.action = action;
      this.lines = lines;
      this.start = range.start;
      this.end = range.end;
    }

    return AceDelta;

  })();

  AceDiff = (function() {

    AceDiff.prototype.deltas = null;

    function AceDiff(editor, diffData) {
      var delta, doc, end, end2, olines, rlines, start, _i, _len, _ref;
      if ((_ref = this.deltas) == null) {
        this.deltas = [];
      }
      doc = editor.getSession().getDocument();
      for (_i = 0, _len = diffData.length; _i < _len; _i++) {
        delta = diffData[_i];
        rlines = delta.revised.split("\n");
        rlines.push("");
        olines = delta.original.split("\n");
        olines.push("");
        start = new Point(delta.offset, 0);
        end = new Point(delta.offset + olines.length - 1, 0);
        end2 = new Point(delta.offset + rlines.length - 1, 0);
        if (delta.original.length === 0) {
          this.deltas.push(new AceDelta("insert", new Range(start, end2), rlines));
        } else if (delta.revised.length === 0) {
          this.deltas.push(new AceDelta("remove", new Range(start, end), olines));
        } else {
          this.deltas.push(new AceDelta("remove", new Range(start, end), rlines));
          this.deltas.push(new AceDelta("insert", new Range(start, end2), rlines));
        }
      }
    }

    return AceDiff;

  })();

  window.AceDiff = AceDiff;

}).call(this);
