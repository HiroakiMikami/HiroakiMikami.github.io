(function() {
  var Preview;

  Preview = (function() {

    function Preview(element) {
      this.element = element;
    }

    Preview.prototype.reload = function(path) {
      return this.element.contentDocument.location.replace(path);
    };

    return Preview;

  })();

  window.Preview = Preview;

}).call(this);
