(function() {
  var Point;

  Point = (function() {

    function Point(row, column) {
      this.row = row;
      this.column = column;
    }

    return Point;

  })();

  window.Point = Point;

}).call(this);
