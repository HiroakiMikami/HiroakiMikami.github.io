(function() {
  var FoldingList,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  FoldingList = (function(_super) {

    __extends(FoldingList, _super);

    FoldingList.prototype.cue = null;

    FoldingList.prototype.marker = null;

    function FoldingList(editor, elements, range, listener) {
      this.remove = __bind(this.remove, this);

      this.hide = __bind(this.hide, this);

      this.show = __bind(this.show, this);

      var getPosition,
        _this = this;
      FoldingList.__super__.constructor.call(this, editor, elements, range, new Offset(0, 0), listener, new Rectangle(null, null), CueType.Folding);
      this.cue = new Cue(editor, range, CueType.Folding);
      getPosition = function(renderer) {
        var p;
        p = null;
        if (_this.range.start.column < 0) {
          if (p == null) {
            p = AceUtils.pointToPositionInScroller(renderer, new Point(_this.range.start.row, 0));
          }
        } else {
          if (p == null) {
            p = AceUtils.pointToPositionInScroller(renderer, _this.range.start);
          }
        }
        return new Position(p.top, 0);
      };
      this.marker = new Marker(editor, range, getPosition, CueType.Folding);
      editor.on("click", function(e) {
        return _this.hide();
      });
      this.cue.componentElement.onclick = function() {
        return _this.show();
      };
      this.marker.componentElement.onclick = function() {
        return _this.show();
      };
      this.cue.show();
      this.marker.show();
    }

    FoldingList.prototype.show = function() {
      if (this.cue != null) {
        this.cue.showMore();
      }
      return FoldingList.__super__.show.call(this);
    };

    FoldingList.prototype.hide = function() {
      if (this.cue != null) {
        this.cue.hideMore();
      }
      return FoldingList.__super__.hide.call(this);
    };

    FoldingList.prototype.remove = function() {
      FoldingList.__super__.remove.call(this);
      this.cue.remove();
      return this.marker.remove();
    };

    return FoldingList;

  })(LargeListPanel);

  window.FoldingList = FoldingList;

}).call(this);
