(function() {
  var Range;

  Range = (function() {

    function Range(start, end) {
      this.start = start;
      this.end = end;
    }

    return Range;

  })();

  window.Range = Range;

}).call(this);
