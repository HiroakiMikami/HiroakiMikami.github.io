(function() {
  var StrikeOut,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  StrikeOut = (function(_super) {

    __extends(StrikeOut, _super);

    StrikeOut.prototype.element = null;

    StrikeOut.prototype.isActive = false;

    function StrikeOut(editor, range, listener) {
      var column, doc, i, line, lineHeight, target, _i, _ref, _ref1,
        _this = this;
      this.range = range;
      this.listener = listener;
      this.positionOption = __bind(this.positionOption, this);

      this.size = __bind(this.size, this);

      this.element = document.createElement("div");
      this.element.className = "Diff";
      doc = editor.getSession().getDocument();
      for (i = _i = _ref = this.range.start.row, _ref1 = this.range.end.row; _ref <= _ref1 ? _i <= _ref1 : _i >= _ref1; i = _ref <= _ref1 ? ++_i : --_i) {
        lineHeight = editor.renderer.lineHeight;
        target = "";
        column = 0;
        if (i === this.range.start.row) {
          column = range.start.column;
        }
        if (i !== this.range.end.row) {
          target = doc.getLine(i).substring(column);
        } else {
          target = doc.getLine(i).substring(column, this.range.end.column);
        }
        line = document.createElement("div");
        line.className = "Delete ace_line";
        line.style["position"] = "absolute";
        line.style["height"] = "" + lineHeight + "px";
        line.style["top"] = "" + ((i - range.start.row) * lineHeight) + "px";
        line.textContent = target;
        this.element.appendChild(line);
      }
      StrikeOut.__super__.constructor.call(this, editor, this.element);
      this.componentElement.className += " StrikeOut";
      this.componentElement.onclick = function() {
        if (_this.listener != null) {
          return _this.listener.onClick();
        }
      };
    }

    StrikeOut.prototype.size = function(renderer) {
      return new Rectangle(100, 100);
    };

    StrikeOut.prototype.positionOption = function(renderer) {
      if (AceUtils.isRangeInScreen(renderer, this.range)) {
        return AceUtils.pointToPositionInScroller(renderer, new Point(this.range.start.row, 0));
      } else {
        return null;
      }
    };

    StrikeOut.prototype.render = function(renderer) {
      var column, i, p, position, _i, _ref, _ref1, _results;
      p = StrikeOut.__super__.render.call(this, renderer);
      if (p != null) {
        _results = [];
        for (i = _i = _ref = this.range.start.row, _ref1 = this.range.end.row; _ref <= _ref1 ? _i <= _ref1 : _i >= _ref1; i = _ref <= _ref1 ? ++_i : --_i) {
          column = 0;
          if (i === this.range.start.row) {
            column = this.range.start.column;
          }
          position = AceUtils.pointToPositionInScroller(renderer, new Point(i, column));
          _results.push(this.element.children[i - this.range.start.row].style["left"] = "" + (position.left - p.left) + "px");
        }
        return _results;
      }
    };

    return StrikeOut;

  })(Component);

  window.StrikeOut = StrikeOut;

}).call(this);
